#ifndef PRINT_STRUCT_H
#define PRINT_STRUCT_H

#include <stdio.h>

#include "const_struct.h"

void print_struct(struct Book book, FILE *file);

#endif // PRINT_STRUCT_H
