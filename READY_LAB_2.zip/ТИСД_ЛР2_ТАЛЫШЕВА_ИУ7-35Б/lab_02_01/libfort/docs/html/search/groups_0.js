var searchData=
[
  ['basicstyles_355',['BasicStyles',['../group__BasicStyles.html',1,'']]]
];
