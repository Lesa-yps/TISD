var searchData=
[
  ['basicstyles_1',['BasicStyles',['../group__BasicStyles.html',1,'']]]
];
