var searchData=
[
  ['default_5fproperties_179',['default_properties',['../classfort_1_1table_1_1default__properties.html',1,'fort::table']]]
];
