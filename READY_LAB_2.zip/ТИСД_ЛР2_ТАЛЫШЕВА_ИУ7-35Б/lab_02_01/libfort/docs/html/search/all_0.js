var searchData=
[
  ['add_5fstrategy_0',['add_strategy',['../fort_8hpp.html#a90d7e4b53ec42f4eddd9e63eb02abca4',1,'fort']]]
];
