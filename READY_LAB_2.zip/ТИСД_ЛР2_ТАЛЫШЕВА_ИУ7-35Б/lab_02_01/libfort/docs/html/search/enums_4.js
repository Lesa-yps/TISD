var searchData=
[
  ['text_5falign_296',['text_align',['../fort_8hpp.html#a895f73752fc847c22853fd363a575b04',1,'fort']]],
  ['text_5fstyle_297',['text_style',['../fort_8hpp.html#aca558b21bbb52c9c28de9811bec32061',1,'fort']]]
];
