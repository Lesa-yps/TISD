var searchData=
[
  ['ft_5fadding_5fstrategy_290',['ft_adding_strategy',['../fort_8h.html#aeed2958a1823084ca6e71883b075baa5',1,'fort.h']]],
  ['ft_5fcolor_291',['ft_color',['../fort_8h.html#a8a64c62f618f7c34310da2e2ef31f63f',1,'fort.h']]],
  ['ft_5frow_5ftype_292',['ft_row_type',['../fort_8h.html#a06d9536a2e476d68f5055820535d3b34',1,'fort.h']]],
  ['ft_5ftext_5falignment_293',['ft_text_alignment',['../fort_8h.html#a3ce6dedcf688e310a3cfbb5cdae9d32c',1,'fort.h']]],
  ['ft_5ftext_5fstyle_294',['ft_text_style',['../fort_8h.html#abc496f06f2a4c7fb58b1730ce813be0b',1,'fort.h']]]
];
