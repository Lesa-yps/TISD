.. libfort documentation master file, created by
   sphinx-quickstart on Sat May  5 13:10:07 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to libfort's documentation!
===================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   introduction
   reference



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
