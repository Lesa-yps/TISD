#ifndef SWAP_H
#define SWAP_H

void swap(void *pbeg, int size, int i, int j);

#endif // SWAP_H
