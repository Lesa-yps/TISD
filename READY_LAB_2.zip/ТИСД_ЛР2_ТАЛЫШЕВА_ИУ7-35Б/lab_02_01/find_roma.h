#ifndef FIND_ROMA_H
#define FIND_ROMA_H

#include <wchar.h>
#include "fort.h"

#include "const_struct.h"
#include "read_struct.h"
#include "print_table_struct.h"

int find_roma(struct Book books[], int n);

#endif // FIND_ROMA_H
