#ifndef PRINT_TABLE_STRUCT_H
#define PRINT_TABLE_STRUCT_H

#include <stdio.h>
#include "fort.h"

#include "const_struct.h"

void print_table_struct(struct Book book, ft_table_t *table, int ind);

#endif // PRINT_TABLE_STRUCT_H
