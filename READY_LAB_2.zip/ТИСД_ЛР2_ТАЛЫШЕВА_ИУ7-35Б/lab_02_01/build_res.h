#ifndef BUILD_RES_H
#define BUILD_RES_H

#include <stdio.h>
#include <time.h>
#include "fort.h"
#include <string.h>

#include "const_struct.h"
#include "sort_rec.h"
#include "sort_simple.h"

// функция
void build_res(struct Book books[], struct Book_key book_keys[], int n);

#endif // BUILD_RES_H
