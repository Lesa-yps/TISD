#ifndef CLEAN_BUF_H
#define CLEAN_BUF_H

#include <stdio.h>
#include <wchar.h>

//функция чистит буфер
void clean_buf(void);

#endif // CLEAN_BUF_H
